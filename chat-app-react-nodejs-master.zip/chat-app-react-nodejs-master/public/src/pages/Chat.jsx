import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { io } from "socket.io-client";
import styled from "styled-components";
import { allUsersRoute, host } from "../utils/APIRoutes";
import ChatContainer from "../components/ChatContainer";
import Contacts from "../components/Contacts";
import Welcome from "../components/Welcome";

export default function Chat() {
  const navigate = useNavigate();
  const socket = useRef();
  const [contacts, setContacts] = useState([]);
  const [currentChat, setCurrentChat] = useState(undefined);
  const [currentUser, setCurrentUser] = useState(undefined);
  const [onlineUsers, setOnlineUsers] = useState([]);

  // ✅ 1. Load user from localStorage
  useEffect(() => {
    const fetchUser = async () => {
      const storedUser = localStorage.getItem(process.env.REACT_APP_LOCALHOST_KEY);
      if (!storedUser) {
        navigate("/login");
      } else {
        setCurrentUser(JSON.parse(storedUser));
      }
    };
    fetchUser();
  }, [navigate]);

  // ✅ 2. Connect to socket after user is set
  useEffect(() => {
    if (currentUser) {
      socket.current = io(host);
      socket.current.emit("add-user", currentUser._id);

      // 🔁 Listen for online users update from backend
      socket.current.on("update-online-users", (onlineUserIds) => {
        setOnlineUsers(onlineUserIds);
      });

      // Clean up the socket connection on component unmount
      return () => {
        socket.current.disconnect();
      };
    }
  }, [currentUser]);

  // ✅ 3. Fetch contacts
  useEffect(() => {
    const fetchContacts = async () => {
      if (currentUser) {
        if (currentUser.isAvatarImageSet) {
          const { data } = await axios.get(`${allUsersRoute}/${currentUser._id}`);
          setContacts(data);
        } else {
          navigate("/setAvatar");
        }
      }
    };
    fetchContacts();
  }, [currentUser, navigate]);

  // ✅ 4. Handle selecting a chat
  const handleChatChange = (chat) => {
    setCurrentChat(chat);
  };

  return (
    <Container>
      <div className="container">
        <Contacts
          contacts={contacts}
          changeChat={handleChatChange}
          onlineUsers={onlineUsers}
        />
        {currentChat === undefined ? (
          <Welcome />
        ) : (
          <ChatContainer currentChat={currentChat} socket={socket} />
        )}
      </div>
    </Container>
  );
}

const Container = styled.div`
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 2rem;
  gap: 2rem;
  background: linear-gradient(135deg, #141e30, #243b55);
  overflow: hidden;

  .container {
    height: 85vh;
    width: 85vw;
    background: rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 1.5rem;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
    display: grid;
    grid-template-columns: 25% 75%;
    overflow: hidden;
    transition: all 0.3s ease-in-out;

    @media screen and (max-width: 1080px) {
      grid-template-columns: 30% 70%;
    }

    @media screen and (max-width: 768px) {
      grid-template-columns: 100%;
      grid-template-rows: auto auto;
      height: auto;
      width: 95vw;
      border-radius: 2rem;
      margin-top: 2rem;
      margin-bottom: 2rem;
      padding: 1.5rem;
    }

    &:hover {
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.35);
      transform: scale(1.01);
    }
  }
`;
