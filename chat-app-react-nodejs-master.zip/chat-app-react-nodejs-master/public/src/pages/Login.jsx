import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";
import Logo from "../assets/logo.svg"; // (if you have a logo)
import { loginRoute } from "../utils/APIRoutes";
import axios from "axios";
import { toast } from "react-toastify";

export default function Login() {
  const navigate = useNavigate();
  const [values, setValues] = useState({ username: "", password: "" });

  const toastOptions = {
    position: "bottom-right",
    autoClose: 8000,
    pauseOnHover: true,
    draggable: true,
    theme: "dark",
  };

  useEffect(() => {
    if (localStorage.getItem(process.env.REACT_APP_LOCALHOST_KEY)) {
      navigate("/");
    }
  }, [navigate]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const { username, password } = values;
    if (handleValidation()) {
      const { data } = await axios.post(loginRoute, { username, password });
      if (data.status === false) {
        toast.error(data.msg, toastOptions);
      }
      if (data.status === true) {
        localStorage.setItem(
          process.env.REACT_APP_LOCALHOST_KEY,
          JSON.stringify(data.user)
        );
        navigate("/");
      }
    }
  };

  const handleValidation = () => {
    const { username, password } = values;
    if (username.length === 0 || password.length === 0) {
      toast.error("Username and Password are required.", toastOptions);
      return false;
    }
    return true;
  };

  const handleChange = (event) => {
    setValues({ ...values, [event.target.name]: event.target.value });
  };

  return (
    <FormContainer>
      <form onSubmit={(e) => handleSubmit(e)}>
        <div className="brand">
          <img src={Logo} alt="logo" />
          <h1>Intalk </h1>
        </div>
        <input
          type="text"
          placeholder="Username"
          name="username"
          onChange={(e) => handleChange(e)}
          min="3"
        />
        <input
          type="password"
          placeholder="Password"
          name="password"
          onChange={(e) => handleChange(e)}
        />
        <button type="submit">Login</button>
        <span>
          Don't have an account? <a href="/register">Register</a>
        </span>
      </form>
    </FormContainer>
  );
}

const FormContainer = styled.div`
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 2rem;
  align-items: center;
  background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
  padding: 2rem;
  overflow: hidden;

  .brand {
    display: flex;
    align-items: center;
    gap: 1rem;
    justify-content: center;

    img {
      height: 4rem;
    }

    h1 {
      color: #ffffff;
      font-size: 2rem;
      text-transform: uppercase;
      letter-spacing: 0.1rem;
    }
  }

  form {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
    background: rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 1.5rem;
    padding: 3rem 4rem;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    transition: all 0.3s ease-in-out;

    input {
      background: rgba(255, 255, 255, 0.1);
      padding: 1rem;
      border: 1px solid transparent;
      border-radius: 0.6rem;
      color: #ffffff;
      width: 100%;
      font-size: 1rem;
      transition: all 0.3s ease-in-out;

      &::placeholder {
        color: #bbb;
      }

      &:focus {
        border: 1px solid #4e0eff;
        background: rgba(255, 255, 255, 0.15);
        outline: none;
      }
    }

    button {
      background: linear-gradient(135deg, #4e0eff, #8e2de2);
      color: white;
      padding: 1rem 2rem;
      border: none;
      font-weight: bold;
      cursor: pointer;
      border-radius: 0.6rem;
      font-size: 1rem;
      text-transform: uppercase;
      transition: background 0.3s ease-in-out, transform 0.2s ease-in-out;

      &:hover {
        background: linear-gradient(135deg, #8e2de2, #4e0eff);
        transform: scale(1.05);
      }
    }

    span {
      color: #ffffff;
      text-transform: uppercase;
      font-size: 0.9rem;

      a {
        color: #8e2de2;
        text-decoration: none;
        font-weight: bold;

        &:hover {
          text-decoration: underline;
        }
      }
    }
  }
`;
