import React from "react";
import styled from "styled-components";

export default function NotificationToast({ message }) {
  return (
    <ToastContainer>
      <div className="toast">{message}</div>
    </ToastContainer>
  );
}

const ToastContainer = styled.div`
  position: absolute;
  bottom: 1rem;
  right: 1.5rem;
  z-index: 10;

  .toast {
    background-color: #333;
    color: white;
    padding: 0.8rem 1.2rem;
    border-radius: 0.5rem;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    animation: fadeInOut 3s ease forwards;
    font-size: 0.95rem;
    max-width: 250px;
    word-wrap: break-word;
  }

  @keyframes fadeInOut {
    0% {
      opacity: 0;
      transform: translateY(20px);
    }
    10% {
      opacity: 1;
      transform: translateY(0);
    }
    90% {
      opacity: 1;
      transform: translateY(0);
    }
    100% {
      opacity: 0;
      transform: translateY(20px);
    }
  }
`;
