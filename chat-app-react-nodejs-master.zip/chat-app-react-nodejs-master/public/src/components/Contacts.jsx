import React, { useState, useEffect } from "react";
import styled from "styled-components";
import Logo from "../assets/logo.svg";

export default function Contacts({ contacts, changeChat, onlineUsers }) {
  const [currentUserName, setCurrentUserName] = useState(undefined);
  const [currentUserImage, setCurrentUserImage] = useState(undefined);
  const [currentSelected, setCurrentSelected] = useState(undefined);
  const [searchTerm, setSearchTerm] = useState(""); // <-- Add search term state

  useEffect(() => {
    const fetchData = async () => {
      const data = await JSON.parse(
        localStorage.getItem(process.env.REACT_APP_LOCALHOST_KEY)
      );
      setCurrentUserName(data.username);
      setCurrentUserImage(data.avatarImage);
    };
    fetchData();
  }, []);

  const changeCurrentChat = (index, contact) => {
    setCurrentSelected(index);
    changeChat(contact);
  };

  // Filter contacts based on search
  const filteredContacts = contacts.filter((contact) =>
    contact.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      {currentUserImage && (
        <Container>
          <div className="brand">
            <img src={Logo} alt="logo" />
            <h3>InTalk</h3>
          </div>

          {/* --- SEARCH BAR --- */}
          <div className="search">
            <input
              type="text"
              placeholder="Search contacts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* --- CONTACTS LIST --- */}
          <div className="contacts">
            {filteredContacts.map((contact, index) => {
              const isOnline = onlineUsers?.includes(contact._id);

              return (
                <div
                  key={contact._id}
                  className={`contact ${
                    index === currentSelected ? "selected" : ""
                  }`}
                  onClick={() => changeCurrentChat(index, contact)}
                >
                  <div className="avatar">
                    <img
                      src={`data:image/svg+xml;base64,${contact.avatarImage}`}
                      alt="avatar"
                    />
                    {isOnline && <span className="online-indicator" />}
                  </div>
                  <div className="username">
                    <h3>{contact.username}</h3>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="current-user">
            <div className="avatar">
              <img
                src={`data:image/svg+xml;base64,${currentUserImage}`}
                alt="avatar"
              />
            </div>
            <div className="username">
              <h2>{currentUserName}</h2>
            </div>
          </div>
        </Container>
      )}
    </>
  );
}

// Add style for the search bar
const Container = styled.div`
  display: grid;
  grid-template-rows: 10% 10% 65% 15%;
  overflow: hidden;
  background-color: #1a1a1a;
  border-radius: 0.5rem 0 0 0.5rem;

  .brand {
    display: flex;
    align-items: center;
    gap: 1rem;
    justify-content: center;
    img {
      height: 2rem;
    }
    h3 {
      color: white;
      text-transform: uppercase;
      letter-spacing: 0.1rem;
      font-weight: bold;
    }
  }

  .search {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0.5rem;
    input {
      width: 90%;
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      border: none;
      font-size: 1rem;
      outline: none;
      background-color: #2a2a2a;
      color: white;
    }
  }

  .contacts {
    display: flex;
    flex-direction: column;
    align-items: center;
    overflow: auto;
    gap: 0.8rem;

    &::-webkit-scrollbar {
      width: 0.2rem;
      &-thumb {
        background-color: #ffffff39;
        width: 0.1rem;
        border-radius: 1rem;
      }
    }

    .contact {
      background-color: #2a2a2a;
      min-height: 5rem;
      cursor: pointer;
      width: 90%;
      border-radius: 0.4rem;
      padding: 0.4rem;
      display: flex;
      gap: 1rem;
      align-items: center;
      position: relative;

      .avatar {
        position: relative;

        img {
          height: 3rem;
          border-radius: 50%;
        }

        .online-indicator {
          position: absolute;
          bottom: 0;
          right: 0;
          width: 0.75rem;
          height: 0.75rem;
          background-color: #4caf50;
          border: 2px solid #2a2a2a;
          border-radius: 50%;
          box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
          z-index: 10;
        }
      }

      .username {
        h3 {
          color: white;
          font-size: 1rem;
          font-weight: 600;
        }
      }

      &:hover {
        background-color: #3a3a3a;
      }

      &:active {
        background-color: #4a4a4a;
      }
    }

    .selected {
      background-color: #4a4a4a;
      box-shadow: 0 0 10px rgba(74, 144, 226, 0.6);
    }
  }

  .current-user {
    background-color: #252525;
    border-top: 1px solid #333333;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 2rem;
    .avatar {
      img {
        height: 4rem;
        max-inline-size: 100%;
        border-radius: 50%;
      }
    }
    .username {
      h2 {
        color: white;
        font-weight: 600;
        font-size: 1.2rem;
      }
    }
    @media screen and (min-width: 720px) and (max-width: 1080px) {
      gap: 0.5rem;
      .username {
        h2 {
          font-size: 1rem;
        }
      }
    }
  }
`;
