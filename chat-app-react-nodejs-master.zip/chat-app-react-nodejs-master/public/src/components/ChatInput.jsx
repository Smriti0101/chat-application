import React, { useState } from "react";
import { BsEmojiSmileFill } from "react-icons/bs";
import { IoMdSend } from "react-icons/io";
import styled from "styled-components";
import Picker from "emoji-picker-react";

export default function ChatInput({ handleSendMsg }) {
  const [msg, setMsg] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const handleEmojiPickerhideShow = () => {
    setShowEmojiPicker(!showEmojiPicker);
  };

  const handleEmojiClick = (event, emojiObject) => {
    let message = msg;
    message += emojiObject.emoji;
    setMsg(message);
  };

  const sendChat = (event) => {
    event.preventDefault();
    if (msg.length > 0) {
      handleSendMsg(msg);
      setMsg("");
    }
  };

  return (
    <Container>
      <div className="button-container">
        <div className="emoji">
          <BsEmojiSmileFill onClick={handleEmojiPickerhideShow} />
          {showEmojiPicker && <Picker onEmojiClick={handleEmojiClick} />}
        </div>
      </div>
      <form className="input-container" onSubmit={(event) => sendChat(event)}>
        <input
          type="text"
          placeholder="type your message here"
          onChange={(e) => setMsg(e.target.value)}
          value={msg}
        />
        <button type="submit">
          <IoMdSend />
        </button>
      </form>
    </Container>
  );
}

const Container = styled.div`
  display: grid;
align-items: center;
grid-template-columns: 5% 95%;
background-color: #1a1a1a; /* Dark background */
border-top: 1px solid #333333;
padding: 0 2rem;
transition: padding 0.3s ease;

@media screen and (min-width: 720px) and (max-width: 1080px) {
  padding: 0 1rem;
  gap: 1rem;
}

.button-container {
  display: flex;
  align-items: center;
  color: white;
  gap: 1rem;

  .emoji {
    position: relative;

    svg {
      font-size: 1.5rem;
      color: #ffff00c8; /* Yellow color for emoji */
      cursor: pointer;
      transition: color 0.3s ease;

      &:hover {
        color: #f1c40f; /* Hover effect to slightly brighten yellow */
      }
    }

    .emoji-picker-react {
      position: absolute;
      top: -350px;
      background-color: #000000;
      box-shadow: 0 5px 10px #333333;
      border-color: #333333;
      border-radius: 0.5rem;
      padding: 1rem;
      transition: top 0.3s ease, opacity 0.3s ease;
      opacity: 0;
      visibility: hidden;

      .emoji-scroll-wrapper::-webkit-scrollbar {
        background-color: #000000;
        width: 5px;
        &-thumb {
          background-color: #333333;
        }
      }

      .emoji-categories {
        button {
          filter: contrast(0);
        }
      }

      .emoji-search {
        background-color: transparent;
        border-color: #333333;
      }

      .emoji-group:before {
        background-color: #000000;
      }
    }

    &:hover .emoji-picker-react {
      opacity: 1;
      visibility: visible; /* Show emoji picker on hover */
    }
  }
}

.input-container {
  width: 100%;
  border-radius: 2rem;
  display: flex;
  align-items: center;
  gap: 2rem;
  background-color: #2a2a2a; /* Dark background for input container */
  padding: 0.5rem;
  transition: background-color 0.3s ease;

  input {
    width: 90%;
    height: 60%;
    background-color: transparent;
    color: white;
    border: none;
    padding-left: 1rem;
    font-size: 1.2rem;
    border-radius: 1rem;
    transition: background-color 0.3s ease;

    &::selection {
      background-color: #333333;
    }

    &:focus {
      outline: none;
      background-color: #333333; /* Highlight background on focus */
    }

    &:hover {
      background-color: #444444; /* Darker background on hover */
    }
  }

  button {
    padding: 0.3rem 2rem;
    border-radius: 2rem;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #4a4a4a;
    border: none;
    transition: background-color 0.3s ease;

    @media screen and (min-width: 720px) and (max-width: 1080px) {
      padding: 0.3rem 1rem;
      svg {
        font-size: 1rem;
      }
    }

    svg {
      font-size: 2rem;
      color: white;
      transition: color 0.3s ease;
    }

    &:hover {
      background-color: #5a5a5a; /* Lighter background on hover */
    }

    &:active {
      background-color: #333333; /* Even darker background when active */
    }

    &:hover svg {
      color: #f1c40f; /* Change color of icon on hover */
    }
  }
}

`;
